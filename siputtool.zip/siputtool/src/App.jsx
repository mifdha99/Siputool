import React, { useState } from 'react'

export default function App() {
  const [videoUrl, setVideoUrl] = useState('')
  const [keyword, setKeyword] = useState('')
  const [tags, setTags] = useState([])
  const [title, setTitle] = useState('')
  const [date, setDate] = useState('')
  const [calendar, setCalendar] = useState([])

  function generateHashtags(k) {
    if (!k || !k.trim()) return []
    const base = k.toLowerCase().replace(/[^a-z0-9]/g, '')
    const variants = [base, base + 'tok', base + 'viral', base + 'challenge', base + 'tips']
    return Array.from(new Set(variants)).slice(0,6).map(t => '#' + t)
  }

  function onGenerate() {
    setTags(generateHashtags(keyword))
  }

  function addToCalendar() {
    if (!title || !date) return alert('Isi judul dan tanggal dulu.')
    const item = { id: Date.now(), title, date, videoUrl }
    setCalendar(c => [item, ...c])
    setTitle(''); setDate(''); setVideoUrl('')
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-primary">SiputTool</h1>
          <p className="mt-2 text-slate-600">Alat bantu growth TikTok yang etis — tanpa auto-viewer. Fokus pada strategi nyata & tools yang membantu.</p>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 bg-white rounded-2xl shadow">
            <h2 className="font-semibold">Preview Video TikTok</h2>
            <p className="text-xs text-slate-500 mb-2">Tempel URL publik TikTok untuk preview (demo).</p>
            <input value={videoUrl} onChange={e=>setVideoUrl(e.target.value)} placeholder="https://www.tiktok.com/@user/video/..." className="w-full p-2 border rounded mb-3" />
            <div>
              {videoUrl ? (
                <div className="aspect-video">
                  <iframe src={videoUrl} title="preview" className="w-full h-64 border rounded" sandbox="allow-scripts allow-same-origin" />
                </div>
              ) : (
                <div className="text-slate-400">Tempel URL video untuk melihat preview.</div>
              )}
            </div>
          </div>

          <div className="p-4 bg-white rounded-2xl shadow">
            <h2 className="font-semibold">Generator Hashtag & Caption</h2>
            <input value={keyword} onChange={e=>setKeyword(e.target.value)} placeholder="Ketik keyword, contoh: mie ayam" className="w-full p-2 border rounded mb-2" />
            <div className="flex gap-2">
              <button onClick={onGenerate} className="px-3 py-1 rounded bg-primary text-white">Generate</button>
              <button onClick={()=>{ const cap = `Tips singkat tentang ${keyword || 'topik ini'} — tonton sampai akhir 🔥`; navigator.clipboard?.writeText(cap); alert('Template caption disalin ke clipboard') }} className="px-3 py-1 border rounded">Salin template caption</button>
            </div>
            <div className="mt-3">
              {tags.length ? (
                <div className="flex flex-wrap gap-2">{tags.map(t=> <span key={t} className="px-2 py-1 text-sm border rounded">{t}</span>)}</div>
              ) : <div className="text-slate-400 text-sm">Belum ada tag — coba masukkan keyword lalu klik Generate.</div>}
            </div>

            <hr className="my-3" />
            <h3 className="text-sm font-medium">Tips cepat</h3>
            <ul className="text-sm mt-2 list-disc list-inside text-slate-600">
              <li>Hook 2 detik pertama sangat penting.</li>
              <li>Gunakan musik trending + ide orisinal.</li>
              <li>Balas komentar cepat di 1 jam pertama.</li>
            </ul>
          </div>
        </section>

        <section className="mt-6 p-4 bg-white rounded-2xl shadow">
          <h2 className="font-semibold">Kalender Konten (Demo Lokal)</h2>
          <div className="flex flex-col md:flex-row gap-3 mt-3">
            <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Judul konten" className="p-2 border rounded flex-1" />
            <input value={date} onChange={e=>setDate(e.target.value)} type="date" className="p-2 border rounded" />
            <button onClick={addToCalendar} className="px-4 py-2 rounded bg-primary text-white">Tambah</button>
          </div>

          <div className="mt-4">
            {calendar.length === 0 ? (
              <div className="text-slate-400">Belum ada jadwal. Tambahkan ide kamu.</div>
            ) : (
              <ul className="space-y-2">
                {calendar.map(it=>(
                  <li key={it.id} className="p-2 border rounded flex justify-between items-center">
                    <div>
                      <div className="font-medium">{it.title}</div>
                      <div className="text-sm text-slate-500">{it.date}</div>
                      {it.videoUrl && <div className="text-xs text-slate-400">Memiliki URL video</div>}
                    </div>
                    <div className="flex gap-2">
                      <button onClick={()=>alert('Ini demo scheduler. Integrasi TikTok API diperlukan untuk publish otomatis.')} className="px-3 py-1 border rounded">Schedule (demo)</button>
                      <button onClick={()=>{ if (confirm('Hapus item ini?')) { setCalendar(c=>c.filter(x=>x.id!==it.id)) } }} className="px-3 py-1 rounded bg-red-600 text-white">Hapus</button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        <footer className="mt-6 p-4 text-sm text-slate-600">
          <strong>Cara integrasi resmi:</strong>
          <ol className="list-decimal list-inside mt-2">
            <li>Daftar di TikTok for Developers dan dapatkan OAuth keys.</li>
            <li>Hubungkan OAuth untuk membaca analytics / posting (jika diperbolehkan).</li>
            <li>Atau pakai TikTok Ads untuk promosi berbayar yang sah.</li>
          </ol>
        </footer>
      </div>
    </div>
  )
}
